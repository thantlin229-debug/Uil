package com.example.data.repository

import com.example.data.model.PhysicsQuestion

object SamplePhysicsQuestions {

    val defaultQuestions: List<PhysicsQuestion> = listOf(
        PhysicsQuestion(
            id = "miit_mech_1",
            questionNumber = 1,
            questionText = "A projectile is launched from ground level at an angle θ = 45° with an initial velocity of 20 m/s. Assuming g = 10 m/s² and negligible air resistance, what is the maximum horizontal range R?",
            options = listOf(
                "20 meters",
                "40 meters",
                "80 meters",
                "10 meters"
            ),
            correctIndex = 1, // 40 meters
            topic = "Classical Mechanics",
            difficulty = "Easy",
            formulaHint = "R = (v² * sin(2θ)) / g",
            sourceName = "MIIT Physics Sem-1 Exam"
        ),
        PhysicsQuestion(
            id = "miit_em_2",
            questionNumber = 2,
            questionText = "In an LC resonant tank circuit, if the inductance L is quadrupled (4L) and the capacitance C is kept constant, how does the resonant angular frequency ω change?",
            options = listOf(
                "Doubles (2ω)",
                "Halved (ω / 2)",
                "Remains unchanged",
                "Quartered (ω / 4)"
            ),
            correctIndex = 1, // Halved
            topic = "Electromagnetism",
            difficulty = "Medium",
            formulaHint = "ω = 1 / √(L * C)",
            sourceName = "MIIT Physics Lab Test"
        ),
        PhysicsQuestion(
            id = "miit_thermo_3",
            questionNumber = 3,
            questionText = "A Carnot heat engine operates between a hot reservoir at 600 K and a cold reservoir at 300 K. What is the maximum theoretical thermodynamic efficiency η?",
            options = listOf(
                "25%",
                "75%",
                "50%",
                "100%"
            ),
            correctIndex = 2, // 50%
            topic = "Thermodynamics",
            difficulty = "Easy",
            formulaHint = "η = 1 - (Tc / Th)",
            sourceName = "MIIT Thermodynamics"
        ),
        PhysicsQuestion(
            id = "miit_optics_4",
            questionNumber = 4,
            questionText = "In Young's double slit experiment, light with wavelength λ = 500 nm illuminates two slits separated by d = 0.5 mm on a screen placed D = 2.0 m away. What is the fringe width β between adjacent bright fringes?",
            options = listOf(
                "1.0 mm",
                "2.0 mm",
                "0.5 mm",
                "4.0 mm"
            ),
            correctIndex = 1, // 2.0 mm: β = λD/d = 500e-9 * 2 / 0.5e-3 = 2e-3 m = 2 mm
            topic = "Wave Optics",
            difficulty = "Medium",
            formulaHint = "β = (λ * D) / d",
            sourceName = "MIIT Wave Optics Tutorial"
        ),
        PhysicsQuestion(
            id = "miit_quantum_5",
            questionNumber = 5,
            questionText = "According to de Broglie's hypothesis, if an electron's kinetic energy is quadrupled (4K), what happens to its de Broglie wavelength λ?",
            options = listOf(
                "Halved (λ / 2)",
                "Doubled (2λ)",
                "Quartered (λ / 4)",
                "Increases by √2"
            ),
            correctIndex = 0, // λ = h / p = h / √(2mK) -> becomes λ / 2
            topic = "Quantum Physics",
            difficulty = "Hard",
            formulaHint = "λ = h / √(2m * K)",
            sourceName = "MIIT Modern Physics"
        ),
        PhysicsQuestion(
            id = "miit_circuits_6",
            questionNumber = 6,
            questionText = "Three identical 6 Ω resistors are connected in parallel across a 12 V ideal DC voltage source. What is the total current I drawn from the source?",
            options = listOf(
                "2 Amperes",
                "6 Amperes",
                "18 Amperes",
                "0.67 Amperes"
            ),
            correctIndex = 1, // R_eq = 6/3 = 2 Ω; I = 12 / 2 = 6 A
            topic = "Circuits & Electrodynamics",
            difficulty = "Easy",
            formulaHint = "1/Req = Σ(1/Ri), I = V / Req",
            sourceName = "MIIT Electrical Fundamentals"
        ),
        PhysicsQuestion(
            id = "miit_relativity_7",
            questionNumber = 7,
            questionText = "A muon moving with relativistic speed v = 0.8c has a rest lifetime τ₀ = 2.2 μs. From the laboratory observer's reference frame, what is the dilated lifetime of the muon?",
            options = listOf(
                "1.32 μs",
                "2.20 μs",
                "3.67 μs",
                "5.50 μs"
            ),
            correctIndex = 2, // γ = 1 / √(1 - 0.64) = 1/0.6 = 5/3 = 1.667; t = 2.2 * 1.667 ≈ 3.67 μs
            topic = "Special Relativity",
            difficulty = "Hard",
            formulaHint = "t = γ * τ₀, where γ = 1 / √(1 - v²/c²)",
            sourceName = "MIIT Modern Physics"
        )
    )
}
