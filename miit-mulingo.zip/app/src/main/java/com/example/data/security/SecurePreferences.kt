package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Manages up to 3 user-provided Gemini API keys and gamification stats
 * using EncryptedSharedPreferences with fallback to standard preferences.
 */
class SecurePreferences(private val context: Context) {

    private val prefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                "miit_mulingo_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.w("SecurePreferences", "EncryptedSharedPreferences initialization failed, falling back to standard prefs", e)
            context.getSharedPreferences("miit_mulingo_fallback_prefs", Context.MODE_PRIVATE)
        }
    }

    companion object {
        private const val KEY_GEMINI_1 = "gemini_api_key_1"
        private const val KEY_GEMINI_2 = "gemini_api_key_2"
        private const val KEY_GEMINI_3 = "gemini_api_key_3"
        private const val KEY_TOTAL_XP = "total_xp"
        private const val KEY_STREAK = "learning_streak"
        private const val KEY_LAST_STUDY_DAY = "last_study_day"
        private const val KEY_QUESTIONS_SOLVED = "questions_solved"
    }

    fun getApiKey(index: Int): String {
        return when (index) {
            1 -> prefs.getString(KEY_GEMINI_1, "") ?: ""
            2 -> prefs.getString(KEY_GEMINI_2, "") ?: ""
            3 -> prefs.getString(KEY_GEMINI_3, "") ?: ""
            else -> ""
        }
    }

    fun setApiKey(index: Int, key: String) {
        val prefKey = when (index) {
            1 -> KEY_GEMINI_1
            2 -> KEY_GEMINI_2
            3 -> KEY_GEMINI_3
            else -> return
        }
        prefs.edit().putString(prefKey, key.trim()).apply()
    }

    fun getAllConfiguredKeys(): List<String> {
        val keys = mutableListOf<String>()
        val k1 = getApiKey(1)
        val k2 = getApiKey(2)
        val k3 = getApiKey(3)
        if (k1.isNotBlank()) keys.add(k1)
        if (k2.isNotBlank()) keys.add(k2)
        if (k3.isNotBlank()) keys.add(k3)
        return keys
    }

    fun getTotalXp(): Int = prefs.getInt(KEY_TOTAL_XP, 120)

    fun addXp(points: Int): Int {
        val newXp = (getTotalXp() + points).coerceAtLeast(0)
        prefs.edit().putInt(KEY_TOTAL_XP, newXp).apply()
        return newXp
    }

    fun getStreak(): Int = prefs.getInt(KEY_STREAK, 3)

    fun incrementStreak() {
        val currentStreak = getStreak()
        prefs.edit().putInt(KEY_STREAK, currentStreak + 1).apply()
    }

    fun getQuestionsSolved(): Int = prefs.getInt(KEY_QUESTIONS_SOLVED, 8)

    fun incrementQuestionsSolved() {
        prefs.edit().putInt(KEY_QUESTIONS_SOLVED, getQuestionsSolved() + 1).apply()
    }
}
