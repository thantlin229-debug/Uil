package com.example.data.model

data class PhysicsQuestion(
    val id: String,
    val questionNumber: Int,
    val questionText: String,
    val options: List<String>, // Exactly 4 options: A, B, C, D
    val correctIndex: Int, // 0 for A, 1 for B, 2 for C, 3 for D (-1 if unknown until AI verifies)
    val topic: String, // e.g. "Classical Mechanics", "Electromagnetism", "Optics"
    val difficulty: String = "Medium",
    val formulaHint: String? = null,
    val sourceName: String = "MIIT Physics Archive"
) {
    fun getOptionLetter(index: Int): String {
        return when (index) {
            0 -> "A"
            1 -> "B"
            2 -> "C"
            3 -> "D"
            else -> "?"
        }
    }
}
