package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.EvaluationResult
import com.example.data.model.PhysicsQuestion
import com.example.ui.mascots.MascotSvgs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiEvaluator {

    private const val TAG = "GeminiEvaluator"
    private const val MODEL_NAME = "gemini-2.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Evaluates a student's answer using the provided keys with 429 rate-limit fallback.
     */
    suspend fun evaluateAnswerWithFallback(
        question: PhysicsQuestion,
        selectedOptionIndex: Int,
        userKeys: List<String>,
        onFallbackAttempt: ((fromKey: String, toKey: String, reason: String) -> Unit)? = null
    ): EvaluationResult = withContext(Dispatchers.IO) {
        val selectedLetter = question.getOptionLetter(selectedOptionIndex)
        val selectedText = question.options.getOrElse(selectedOptionIndex) { "" }

        // Compile ordered list of candidate keys
        val keyCandidates = mutableListOf<Pair<String, String>>()
        userKeys.forEachIndexed { idx, key ->
            if (key.isNotBlank()) {
                keyCandidates.add("Key #${idx + 1}" to key.trim())
            }
        }
        val buildConfigKey = BuildConfig.GEMINI_API_KEY
        if (buildConfigKey.isNotBlank() && buildConfigKey != "MY_GEMINI_API_KEY") {
            keyCandidates.add("System Key" to buildConfigKey.trim())
        }

        val prompt = buildEvaluationPrompt(question, selectedLetter, selectedText)

        // Attempt each key in order. Fallback on 429 / Rate Limit
        var lastErrorReason = ""
        for (i in keyCandidates.indices) {
            val (keyLabel, apiKey) = keyCandidates[i]
            try {
                Log.d(TAG, "Attempting evaluation with $keyLabel...")
                val responseJson = callGeminiGenerateContent(apiKey, prompt)

                val parsed = parseGeminiResponse(responseJson, selectedLetter, question)
                if (parsed != null) {
                    val keyInfo = if (i > 0) {
                        "Evaluated via $keyLabel (Fallback after previous rate limits)"
                    } else {
                        "Evaluated via $keyLabel"
                    }
                    return@withContext parsed.copy(keyUsedInfo = keyInfo)
                }
            } catch (e: Exception) {
                val errorMsg = e.message ?: "Unknown error"
                Log.w(TAG, "$keyLabel failed: $errorMsg")
                val isRateLimit = errorMsg.contains("429") || errorMsg.contains("RESOURCE_EXHAUSTED", ignoreCase = true)
                lastErrorReason = if (isRateLimit) "HTTP 429 Rate Limit" else errorMsg

                if (i < keyCandidates.size - 1) {
                    val nextLabel = keyCandidates[i + 1].first
                    onFallbackAttempt?.invoke(keyLabel, nextLabel, lastErrorReason)
                }
            }
        }

        // If no keys configured or all keys hit rate-limits/offline, use high quality local Physics Engine fallback
        val isFallbackCorrect = (selectedOptionIndex == question.correctIndex)
        generateOfflinePhysicsEvaluation(
            question = question,
            selectedLetter = selectedLetter,
            isCorrect = isFallbackCorrect,
            reasonNote = if (keyCandidates.isEmpty()) "No Gemini Key Configured (Using Local MIIT Engine)" else "All Keys Hit 429/Offline ($lastErrorReason)"
        )
    }

    /**
     * Calls Gemini API endpoint using OkHttp
     */
    private fun callGeminiGenerateContent(apiKey: String, prompt: String): String {
        val url = "$BASE_URL/$MODEL_NAME:generateContent?key=$apiKey"

        val requestPayload = JSONObject().apply {
            val contents = JSONArray().apply {
                val turn = JSONObject().apply {
                    val parts = JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    }
                    put("parts", parts)
                }
                put(turn)
            }
            put("contents", contents)

            val genConfig = JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.4)
            }
            put("generationConfig", genConfig)
        }

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = requestPayload.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .addHeader("Content-Type", "application/json")
            .build()

        val response = okHttpClient.newCall(request).execute()
        val code = response.code
        val bodyString = response.body?.string() ?: ""

        if (!response.isSuccessful) {
            throw Exception("HTTP $code: $bodyString")
        }

        return bodyString
    }

    private fun buildEvaluationPrompt(
        question: PhysicsQuestion,
        selectedLetter: String,
        selectedText: String
    ): String {
        return """
            You are MIIT Mulingo, a friendly and genius Physics tutor for Myanmar Institute of Information Technology students.
            A student has answered the following physics multiple-choice question.
            
            Question: ${question.questionText}
            Options:
            A) ${question.options.getOrNull(0) ?: ""}
            B) ${question.options.getOrNull(1) ?: ""}
            C) ${question.options.getOrNull(2) ?: ""}
            D) ${question.options.getOrNull(3) ?: ""}
            
            Student Selected: Option $selectedLetter: "$selectedText"
            Known Reference Correct Option: ${question.getOptionLetter(question.correctIndex)}
            
            Task:
            1. Determine whether the student's answer is correct or incorrect.
            2. Provide a detailed, warm, and highly engaging physics concept explanation in conversational Burmese (မြန်မာစကားပြေ သဘာဝကျကျ). Explain why the answer is correct or what common misconception leads to mistakes.
            3. Provide a practical mental math shortcut (လျင်မြန်စွာတွက်ချက်နည်း / Mental Math Shortcut / Dimensional analysis trick) to eliminate wrong answers or calculate the result in under 30 seconds.
            4. Provide an inline raw SVG mascot:
               - If correct: A cute, happy celebrating Golden Star SVG (<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">...) with happy face, sparkles, and gold/yellow flat colors.
               - If incorrect: A cute, encouraging green Owl with round glasses SVG (<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">...) with encouraging gesture.
            5. Award XP (e.g. 15 for correct, 5 for effort if incorrect).
            
            Respond strictly in valid JSON matching this schema:
            {
              "isCorrect": true,
              "correctOption": "B",
              "explanationBurmese": "အဖြေမှန်ကတော့ B ဖြစ်ပါတယ်ခင်ဗျာ။ အဘယ်ကြောင့်ဆိုသော်...",
              "mentalMathTip": "💡 လျင်မြန်စွာတွက်နည်း Shortcut: ...",
              "mascotSvg": "<svg viewBox='0 0 200 200' ...>...</svg>",
              "xpEarned": 15
            }
        """.trimIndent()
    }

    private fun parseGeminiResponse(
        jsonString: String,
        selectedLetter: String,
        question: PhysicsQuestion
    ): EvaluationResult? {
        return try {
            val root = JSONObject(jsonString)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.getJSONObject(0).optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            if (parts.length() == 0) return null
            val rawText = parts.getJSONObject(0).optString("text", "")

            // Parse output json
            val cleanedJson = rawText.trim()
                .removePrefix("```json")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()

            val evalObj = JSONObject(cleanedJson)
            val isCorrect = evalObj.optBoolean("isCorrect", false)
            val correctOption = evalObj.optString("correctOption", question.getOptionLetter(question.correctIndex))
            val explanationBurmese = evalObj.optString("explanationBurmese", "")
            val mentalMathTip = evalObj.optString("mentalMathTip", "")
            val rawMascotSvg = evalObj.optString("mascotSvg", "")
            val xpEarned = evalObj.optInt("xpEarned", if (isCorrect) 15 else 5)

            val safeSvg = MascotSvgs.sanitizeSvg(rawMascotSvg, isCorrect)

            EvaluationResult(
                isCorrect = isCorrect,
                selectedLetter = selectedLetter,
                correctLetter = correctOption,
                explanationBurmese = explanationBurmese.ifBlank { "ဖော်ပြပါ ရူပဗေဒဆိုင်ရာ အဖြေသည် မှန်ကန်တိကျပါသည်။" },
                mentalMathTip = mentalMathTip.ifBlank { "ယူနစ်နှင့် Dimension ခွဲခြမ်းစိတ်ဖြာပြီး အလျင်အမြန် စစ်ဆေးနိုင်ပါသည်။" },
                mascotSvg = safeSvg,
                xpEarned = xpEarned
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing Gemini JSON response", e)
            null
        }
    }

    /**
     * Local physics explanation engine for fallback when offline or when keys reach rate limits.
     */
    private fun generateOfflinePhysicsEvaluation(
        question: PhysicsQuestion,
        selectedLetter: String,
        isCorrect: Boolean,
        reasonNote: String
    ): EvaluationResult {
        val correctLetter = question.getOptionLetter(question.correctIndex)
        val explanationBurmese = when (question.id) {
            "miit_mech_1" -> if (isCorrect) {
                "သာဓုပါ! အဖြေမှန်ကတော့ B (40 meters) ဖြစ်ပါတယ်ခင်ဗျာ။ Horizontal Range ဖော်မြူလာ R = (v² sin 2θ) / g မှာ θ = 45° ဖြစ်လို့ sin(90°) = 1 အမြင့်ဆုံးရောက်ပါတယ်။ ဒါကြောင့် R = 20² / 10 = 400 / 10 = 40 m ရရှိတာဖြစ်ပါတယ်။"
            } else {
                "မမှန်သေးပါဘူးခင်ဗျာ။ အဖြေမှန်က B (40 meters) ဖြစ်ပါတယ်။ ပစ်လွှတ်ထောင့် θ = 45° ဖြစ်တဲ့အခါ Range က အဝေးဆုံးရောက်ပြီး R = v²/g ဖြစ်သွားပါတယ်။ 20² / 10 = 40 m ဖြစ်ပါတယ်။"
            }
            "miit_em_2" -> if (isCorrect) {
                "အရမ်းတော်တယ်! Resonant frequency ω = 1 / √(LC) ဖြစ်ပါတယ်။ L ကို ၄ ဆ တိုးလိုက်တဲ့အခါ (4L) စတုရန်းမူလ (Square root) ထဲက ထွက်လာရင် ၂ ဆ ဖြစ်သွားလို့ frequency က တစ်ဝက် (ω / 2) သို့ ကျဆင်းသွားပါတယ်။"
            } else {
                "အဖြေမှန်ကတော့ B (Halved: ω / 2) ဖြစ်ပါတယ်ခင်ဗျာ။ ကြိမ်နှုန်း ω သည် အင်ဒပ်တန့်စ် L ၏ စတုရန်းမူလ (Square root) နှင့် ပြောင်းပြန်အချိုးကျပါတယ်။ √4 = 2 ဖြစ်လို့ ω မှာ ၂ ပိုင်း ၁ ပိုင်း ဖြစ်သွားပါတယ်။"
            }
            "miit_thermo_3" -> if (isCorrect) {
                "ကွက်တိမှန်ပါတယ်! Carnot engine စွမ်းရည် η = 1 - (Tc / Th) = 1 - (300 / 600) = 1 - 0.5 = 0.5 (50%) ဖြစ်ပါတယ်။"
            } else {
                "အဖြေမှန်ကတော့ C (50%) ဖြစ်ပါတယ်။ အပူချိန် အချိုး Tc/Th = 300/600 = 0.5 ဖြစ်တာကြောင့် အမြင့်ဆုံး စွမ်းရည်မှာ 1 - 0.5 = 50% ဖြစ်ပါတယ်။"
            }
            "miit_optics_4" -> if (isCorrect) {
                "အဖြေမှန်က B (2.0 mm) ဖြစ်ပါတယ်။ Fringe width β = λD / d = (500 × 10⁻⁹ m × 2.0 m) / (0.5 × 10⁻³ m) = 2.0 × 10⁻³ m = 2.0 mm ဖြစ်ပါတယ်။"
            } else {
                "အဖြေမှန်က B (2.0 mm) ဖြစ်ပါတယ်။ β = λD / d ဖော်မြူလာအရ wavelength တိုးရင် fringe width ပိုကျယ်လာပြီး slit အကွာအဝေး d ကျဉ်းရင်လည်း ပိုကျယ်လာပါတယ်။"
            }
            "miit_quantum_5" -> if (isCorrect) {
                "အထူးကောင်းမွန်ပါတယ်! de Broglie wavelength λ = h / p = h / √(2mK) ဖြစ်ပါတယ်။ Kinetic energy K ကို ၄ ဆ တိုးရင် √4 = 2 ဆ အပိုင်းခြေတိုးလာတာကြောင့် လှိုင်းအလျား λ သည် တစ်ဝက် (λ / 2) ဖြစ်သွားပါတယ်။"
            } else {
                "အဖြေမှန်က A (Halved: λ / 2) ဖြစ်ပါတယ်။ စွမ်းအင် ၄ ဆ တိုးသော်လည်း စတုရန်းမူလ √4 = 2 ဖြစ်တာကြောင့် လှိုင်းအလျားမှာ တစ်ဝက်သာ ကျန်ရှိပါတော့တယ်။"
            }
            else -> if (isCorrect) {
                "ဂုဏ်ယူပါတယ်! သင်ရွေးချယ်လိုက်သော အဖြေ $selectedLetter သည် မှန်ကန်တိကျပါသည်။ ရူပဗေဒသဘောတရားအရ Formula နှင့် အတိုင်းအတာများ ကိုက်ညီမှုရှိပါသည်။"
            } else {
                "သင်ရွေးချယ်လိုက်သော အဖြေမှာ မှားယွင်းနေပါသည်။ အဖြေမှန်မှာ Option $correctLetter ဖြစ်ပြီး သက်ဆိုင်ရာ ညီမျှခြင်းအရ တွက်ချက်ရယူနိုင်ပါသည်။"
            }
        }

        val mentalMathTip = when (question.id) {
            "miit_mech_1" -> "⚡ 45° ပစ်လွှတ်မှုမှာ sin(2θ) = 1 အမြဲဖြစ်လို့ v² / g ကို စိတ်ထဲကတင် 400 / 10 = 40 လို့ ၃ စက္ကန့်အတွင်း အလွယ်တွက်နိုင်ပါတယ်!"
            "miit_em_2" -> "⚡ Inverse square root ဆက်သွယ်ချက်ကြောင့် L ကို 4 ဆတိုးရင် frequency က √4 = 2 ပိုင်း ၁ ပိုင်း ဖြစ်မယ်ဆိုတာ တိုက်ရိုက်သိနိုင်ပါတယ်။"
            "miit_thermo_3" -> "⚡ 300K ဟာ 600K ရဲ့ တစ်ဝက် (1/2) အတိအကျဖြစ်လို့ Efficiency ဟာလည်း 1 - 1/2 = 50% လို့ ချက်ချင်းထွက်ပါတယ်။"
            "miit_optics_4" -> "⚡ 500 nm × 2 m = 1000 nm·m = 10⁻⁶။ ၎င်းကို 0.5 × 10⁻³ နဲ့ စားရင် 10⁻⁶ / (0.5 × 10⁻³) = 2 × 10⁻³ m = 2 mm ရပါသည်!"
            "miit_quantum_5" -> "⚡ de Broglie λ ∝ 1/√K အမြဲမှတ်ထားပါ: K ကို ၄ ဆတိုးရင် λ က 1/√4 = 1/2 ဖြစ်ပါတယ်!"
            else -> "⚡ Dimensional Analysis Shortcut: ယူနစ်များကို ကြည့်ပြီး မကိုက်ညီသော Option များကို ဦးစွာ ပယ်ထုတ်နိုင်ပါသည်။"
        }

        return EvaluationResult(
            isCorrect = isCorrect,
            selectedLetter = selectedLetter,
            correctLetter = correctLetter,
            explanationBurmese = explanationBurmese,
            mentalMathTip = mentalMathTip,
            mascotSvg = if (isCorrect) MascotSvgs.STAR_CELEBRATING_SVG else MascotSvgs.OWL_ENCOURAGING_SVG,
            xpEarned = if (isCorrect) 15 else 5,
            keyUsedInfo = reasonNote
        )
    }

    /**
     * Helper to test a key entered by user
     */
    suspend fun testApiKey(apiKey: String): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("API Key cannot be empty"))
        }
        try {
            val prompt = "Respond in 3 words: 'Key is active'"
            val res = callGeminiGenerateContent(apiKey.trim(), prompt)
            if (res.contains("candidates")) {
                Result.success("Connected successfully!")
            } else {
                Result.failure(Exception("Unexpected response from Gemini"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
