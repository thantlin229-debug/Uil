package com.example.data.model

data class EvaluationResult(
    val isCorrect: Boolean,
    val selectedLetter: String,
    val correctLetter: String,
    val explanationBurmese: String,
    val mentalMathTip: String,
    val mascotSvg: String,
    val xpEarned: Int,
    val keyUsedInfo: String = "Gemini AI Evaluation",
    val timestamp: Long = System.currentTimeMillis()
)
