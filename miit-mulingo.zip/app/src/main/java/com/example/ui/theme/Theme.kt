package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = DuoGreen,
    onPrimary = DuoWhite,
    secondary = DuoBlue,
    onSecondary = DuoWhite,
    tertiary = DuoGold,
    background = Color(0xFF131F24),
    surface = Color(0xFF1E2E36),
    onBackground = DuoWhite,
    onSurface = DuoWhite
  )

private val LightColorScheme =
  lightColorScheme(
    primary = DuoGreen,
    onPrimary = DuoWhite,
    secondary = DuoBlue,
    onSecondary = DuoWhite,
    tertiary = DuoGold,
    background = DuoGrayLight,
    surface = DuoWhite,
    onBackground = DuoDark,
    onSurface = DuoDark
  )

@Composable
fun MIITMulingoTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

