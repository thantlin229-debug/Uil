package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiEvaluator
import com.example.data.model.EvaluationResult
import com.example.data.model.PhysicsQuestion
import com.example.data.pdf.PdfQuestionExtractor
import com.example.data.repository.SamplePhysicsQuestions
import com.example.data.security.SecurePreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class QuizUiState(
    val questions: List<PhysicsQuestion> = SamplePhysicsQuestions.defaultQuestions,
    val currentQuestionIndex: Int = 0,
    val selectedOptionIndex: Int = -1,
    val isEvaluating: Boolean = false,
    val evaluationResult: EvaluationResult? = null,
    val totalXp: Int = 120,
    val streak: Int = 3,
    val activeDeckTitle: String = "MIIT Physics Standard",
    val key1: String = "",
    val key2: String = "",
    val key3: String = "",
    val fallbackNotice: String? = null,
    val showSettingsDialog: Boolean = false,
    val showPdfDialog: Boolean = false,
    val loadedPdfName: String? = null,
    val loadedPdfPageCount: Int = 0,
    val loadedPdfQuestionCount: Int = 0,
    val loadedPdfPreviewBitmap: Bitmap? = null,
    val isPdfLoading: Boolean = false,
    val statusMessage: String? = null
) {
    val currentQuestion: PhysicsQuestion?
        get() = questions.getOrNull(currentQuestionIndex)

    val isDeckFinished: Boolean
        get() = questions.isNotEmpty() && currentQuestionIndex >= questions.size
}

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val securePrefs = SecurePreferences(application)

    private val _uiState = MutableStateFlow(
        QuizUiState(
            totalXp = securePrefs.getTotalXp(),
            streak = securePrefs.getStreak(),
            key1 = securePrefs.getApiKey(1),
            key2 = securePrefs.getApiKey(2),
            key3 = securePrefs.getApiKey(3)
        )
    )
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()

    fun selectOption(index: Int) {
        if (_uiState.value.isEvaluating || _uiState.value.evaluationResult != null) return
        _uiState.update { it.copy(selectedOptionIndex = index) }
    }

    fun submitAnswer() {
        val state = _uiState.value
        val question = state.currentQuestion ?: return
        val selectedIndex = state.selectedOptionIndex
        if (selectedIndex == -1 || state.isEvaluating) return

        _uiState.update {
            it.copy(
                isEvaluating = true,
                fallbackNotice = null
            )
        }

        viewModelScope.launch {
            val keys = listOf(state.key1, state.key2, state.key3)
            val result = GeminiEvaluator.evaluateAnswerWithFallback(
                question = question,
                selectedOptionIndex = selectedIndex,
                userKeys = keys,
                onFallbackAttempt = { fromKey, toKey, reason ->
                    _uiState.update {
                        it.copy(fallbackNotice = "$fromKey rate limited ($reason) ➔ Falling back to $toKey")
                    }
                }
            )

            // Update stats
            val newXp = securePrefs.addXp(result.xpEarned)
            if (result.isCorrect) {
                securePrefs.incrementStreak()
            }
            securePrefs.incrementQuestionsSolved()

            _uiState.update {
                it.copy(
                    isEvaluating = false,
                    evaluationResult = result,
                    totalXp = newXp,
                    streak = securePrefs.getStreak()
                )
            }
        }
    }

    fun nextQuestion() {
        val state = _uiState.value
        val nextIdx = state.currentQuestionIndex + 1
        _uiState.update {
            it.copy(
                currentQuestionIndex = if (nextIdx < it.questions.size) nextIdx else 0,
                selectedOptionIndex = -1,
                evaluationResult = null,
                fallbackNotice = null
            )
        }
    }

    fun saveApiKeys(k1: String, k2: String, k3: String) {
        securePrefs.setApiKey(1, k1)
        securePrefs.setApiKey(2, k2)
        securePrefs.setApiKey(3, k3)
        _uiState.update {
            it.copy(
                key1 = k1.trim(),
                key2 = k2.trim(),
                key3 = k3.trim(),
                statusMessage = "Gemini API Keys saved securely!"
            )
        }
    }

    suspend fun testApiKey(key: String): Result<String> {
        return GeminiEvaluator.testApiKey(key)
    }

    fun openPdfPickerSheet() {
        _uiState.update { it.copy(showPdfDialog = true) }
    }

    fun closePdfDialog() {
        _uiState.update { it.copy(showPdfDialog = false) }
    }

    fun openSettingsDialog() {
        _uiState.update { it.copy(showSettingsDialog = true) }
    }

    fun closeSettingsDialog() {
        _uiState.update { it.copy(showSettingsDialog = false) }
    }

    fun processPdfUri(uri: Uri, fileName: String) {
        _uiState.update { it.copy(isPdfLoading = true, statusMessage = "Processing Physics PDF via native PdfRenderer...") }
        viewModelScope.launch {
            val result = PdfQuestionExtractor.processPdf(getApplication(), uri, fileName)
            _uiState.update {
                it.copy(
                    isPdfLoading = false,
                    loadedPdfName = result.fileName,
                    loadedPdfPageCount = result.pageCount,
                    loadedPdfQuestionCount = result.questions.size,
                    loadedPdfPreviewBitmap = result.renderedPreviewBitmap,
                    questions = if (result.questions.isNotEmpty()) result.questions else it.questions,
                    currentQuestionIndex = 0,
                    selectedOptionIndex = -1,
                    evaluationResult = null,
                    activeDeckTitle = result.fileName,
                    showPdfDialog = true,
                    statusMessage = "Extracted ${result.questions.size} physics questions from ${result.fileName}"
                )
            }
        }
    }

    fun resetToDefaultQuestions() {
        _uiState.update {
            it.copy(
                questions = SamplePhysicsQuestions.defaultQuestions,
                currentQuestionIndex = 0,
                selectedOptionIndex = -1,
                evaluationResult = null,
                activeDeckTitle = "MIIT Physics Standard"
            )
        }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }
}
