package com.example.ui.mascots

object MascotSvgs {

    val STAR_CELEBRATING_SVG = """
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="100%" height="100%">
          <defs>
            <radialGradient id="starGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#FFF9D2"/>
              <stop offset="60%" stop-color="#FFC800"/>
              <stop offset="100%" stop-color="#E5A500"/>
            </radialGradient>
            <filter id="shadow" x="-10%" y="-10%" width="130%" height="130%">
              <feDropShadow dx="0" dy="6" stdDeviation="4" flood-color="#B8860B" flood-opacity="0.3"/>
            </filter>
          </defs>
          <!-- Confetti -->
          <circle cx="35" cy="45" r="5" fill="#58CC02"/>
          <circle cx="205" cy="50" r="6" fill="#1CB0F6"/>
          <rect x="25" y="105" width="8" height="8" rx="2" fill="#FF4B4B" transform="rotate(25 25 105)"/>
          <rect x="200" y="115" width="9" height="9" rx="2" fill="#CE82FF" transform="rotate(-30 200 115)"/>
          <circle cx="50" cy="180" r="4" fill="#FF9600"/>
          <circle cx="190" cy="175" r="5" fill="#58CC02"/>
          
          <!-- Sparkles -->
          <path d="M120 15 L124 28 L137 32 L124 36 L120 49 L116 36 L103 32 L116 28 Z" fill="#FFDF00"/>
          <path d="M40 80 L42 86 L48 88 L42 90 L40 96 L38 90 L32 88 L38 86 Z" fill="#FFC800"/>
          <path d="M195 75 L197 81 L203 83 L197 85 L195 91 L193 85 L187 83 L193 81 Z" fill="#FFC800"/>

          <!-- Golden Star Character Body -->
          <path d="M120 40 
                   L142 86 A6 6 0 0 0 148 90 
                   L198 96 A6 6 0 0 1 201 106 
                   L164 140 A6 6 0 0 0 162 147 
                   L172 196 A6 6 0 0 1 163 203 
                   L122 178 A6 6 0 0 0 116 178 
                   L75 203 A6 6 0 0 1 66 196 
                   L76 147 A6 6 0 0 0 74 140 
                   L37 106 A6 6 0 0 1 40 96 
                   L90 90 A6 6 0 0 0 96 86 Z" 
                fill="url(#starGlow)" stroke="#E5A500" stroke-width="4" stroke-linejoin="round" filter="url(#shadow)"/>

          <!-- Rosy Cheeks -->
          <ellipse cx="92" cy="138" rx="8" ry="5" fill="#FF8A8A" opacity="0.8"/>
          <ellipse cx="148" cy="138" rx="8" ry="5" fill="#FF8A8A" opacity="0.8"/>

          <!-- Eyes (Big Happy Arches) -->
          <path d="M88 126 Q96 114 104 126" stroke="#4A3B00" stroke-width="4.5" stroke-linecap="round" fill="none"/>
          <path d="M136 126 Q144 114 152 126" stroke="#4A3B00" stroke-width="4.5" stroke-linecap="round" fill="none"/>

          <!-- Joyful Big Smile -->
          <path d="M106 138 Q120 160 134 138 Z" fill="#D32F2F" stroke="#4A3B00" stroke-width="2"/>
          <path d="M112 144 Q120 152 128 144" fill="#FF8A80"/>

          <!-- Waving Hands / Thumbs Up -->
          <ellipse cx="60" cy="140" rx="9" ry="12" fill="#FFC800" stroke="#E5A500" stroke-width="3" transform="rotate(-35 60 140)"/>
          <ellipse cx="180" cy="140" rx="9" ry="12" fill="#FFC800" stroke="#E5A500" stroke-width="3" transform="rotate(35 180 140)"/>
        </svg>
    """.trimIndent()

    val OWL_ENCOURAGING_SVG = """
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="100%" height="100%">
          <defs>
            <filter id="owlShadow" x="-10%" y="-10%" width="130%" height="130%">
              <feDropShadow dx="0" dy="5" stdDeviation="4" flood-color="#2D5A02" flood-opacity="0.3"/>
            </filter>
          </defs>
          
          <!-- Encouraging Speech/Thinking Bubble -->
          <rect x="145" y="20" width="80" height="35" rx="12" fill="#FFFFFF" stroke="#E5E5E5" stroke-width="2"/>
          <polygon points="160,55 170,55 155,68" fill="#FFFFFF"/>
          <polygon points="159,55 171,55 155,68" stroke="#E5E5E5" stroke-width="2" fill="none"/>
          <text x="185" y="42" font-family="sans-serif" font-weight="bold" font-size="12" fill="#58CC02" text-anchor="middle">Keep going!</text>

          <!-- Feet -->
          <ellipse cx="100" cy="208" rx="14" ry="7" fill="#FF9600"/>
          <ellipse cx="140" cy="208" rx="14" ry="7" fill="#FF9600"/>

          <!-- Owl Body -->
          <path d="M70 100 C70 55 170 55 170 100 C170 155 165 200 120 200 C75 200 70 155 70 100 Z" 
                fill="#58CC02" stroke="#46A302" stroke-width="4" filter="url(#owlShadow)"/>

          <!-- Belly Patch -->
          <ellipse cx="120" cy="155" rx="35" ry="32" fill="#D7FFB8"/>
          <!-- Belly Feathers / Ripples -->
          <path d="M108 145 Q120 155 132 145" stroke="#58CC02" stroke-width="3" stroke-linecap="round" fill="none"/>
          <path d="M112 162 Q120 170 128 162" stroke="#58CC02" stroke-width="3" stroke-linecap="round" fill="none"/>

          <!-- Left Wing (Waving Upwards Encouragingly) -->
          <path d="M70 115 C55 95 40 115 50 145 C60 160 70 150 72 135 Z" 
                fill="#46A302" stroke="#378202" stroke-width="3"/>

          <!-- Right Wing (Tucked) -->
          <path d="M170 120 C182 135 180 155 168 168 C163 162 165 140 168 125 Z" 
                fill="#46A302"/>

          <!-- Big White Eyes -->
          <circle cx="98" cy="98" r="22" fill="#FFFFFF" stroke="#46A302" stroke-width="3"/>
          <circle cx="142" cy="98" r="22" fill="#FFFFFF" stroke="#46A302" stroke-width="3"/>

          <!-- Physics Spectacles (Golden wireframe) -->
          <circle cx="98" cy="98" r="23" fill="none" stroke="#FFC800" stroke-width="3"/>
          <circle cx="142" cy="98" r="23" fill="none" stroke="#FFC800" stroke-width="3"/>
          <line x1="120" y1="98" x2="120" y2="98" stroke="#FFC800" stroke-width="3"/>
          <path d="M118 97 Q120 93 122 97" stroke="#FFC800" stroke-width="3" fill="none"/>

          <!-- Eye Pupils (Warm curious gaze) -->
          <circle cx="102" cy="98" r="11" fill="#1CB0F6"/>
          <circle cx="104" cy="97" r="5" fill="#042C48"/>
          <circle cx="106" cy="95" r="2" fill="#FFFFFF"/>

          <circle cx="138" cy="98" r="11" fill="#1CB0F6"/>
          <circle cx="136" cy="97" r="5" fill="#042C48"/>
          <circle cx="138" cy="95" r="2" fill="#FFFFFF"/>

          <!-- Orange Beak -->
          <polygon points="113,108 127,108 120,123" fill="#FF9600" stroke="#E58500" stroke-width="1.5"/>

          <!-- Cute Cheeks -->
          <ellipse cx="80" cy="115" rx="7" ry="4" fill="#FFC800" opacity="0.6"/>
          <ellipse cx="160" cy="115" rx="7" ry="4" fill="#FFC800" opacity="0.6"/>
        </svg>
    """.trimIndent()

    fun sanitizeSvg(rawSvg: String?, isCorrect: Boolean): String {
        if (rawSvg.isNullOrBlank()) {
            return if (isCorrect) STAR_CELEBRATING_SVG else OWL_ENCOURAGING_SVG
        }
        val cleaned = rawSvg.trim()
        val svgStart = cleaned.indexOf("<svg", ignoreCase = true)
        val svgEnd = cleaned.lastIndexOf("</svg>", ignoreCase = true)
        return if (svgStart != -1 && svgEnd != -1 && svgEnd > svgStart) {
            cleaned.substring(svgStart, svgEnd + 6)
        } else {
            if (isCorrect) STAR_CELEBRATING_SVG else OWL_ENCOURAGING_SVG
        }
    }
}
