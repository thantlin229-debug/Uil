package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.QuizViewModel
import kotlinx.coroutines.launch

@Composable
fun QuizScreen(
    viewModel: QuizViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // SAF Document Picker for Physics PDF
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            var displayName = "physics_exam.pdf"
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        displayName = cursor.getString(nameIndex) ?: displayName
                    }
                }
            } catch (e: Exception) {
                // Ignore fallback to default name
            }
            viewModel.processPdfUri(uri, displayName)
        }
    }

    // Show transient status messages
    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            DuoTopBar(
                totalXp = uiState.totalXp,
                streak = uiState.streak,
                activeSourceName = uiState.activeDeckTitle,
                onOpenPdfPicker = { pdfPickerLauncher.launch(arrayOf("application/pdf")) },
                onOpenSettings = { viewModel.openSettingsDialog() }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DuoGrayLight)
        ) {
            val currentQuestion = uiState.currentQuestion

            if (uiState.isPdfLoading) {
                // PDF Parsing Loading state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        color = DuoBlue,
                        strokeWidth = 4.dp,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Parsing Physics PDF...",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = DuoDark
                    )
                    Text(
                        text = "Native Android PdfRenderer is rendering pages & extracting questions",
                        fontSize = 13.sp,
                        color = DuoSubtext,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            } else if (currentQuestion == null) {
                // Empty questions fallback
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "No Questions Available",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    DuoTactileButton(
                        text = "Load MIIT Questions",
                        onClick = { viewModel.resetToDefaultQuestions() }
                    )
                }
            } else {
                // Main Quiz Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .padding(bottom = if (uiState.evaluationResult != null) 380.dp else 90.dp)
                ) {
                    // Progress Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DuoProgressBar(
                            current = uiState.currentQuestionIndex + 1,
                            total = uiState.questions.size,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "${uiState.currentQuestionIndex + 1}/${uiState.questions.size}",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = DuoSubtext
                        )
                    }

                    // Key Fallback Alert Notification Banner if 429 was encountered
                    if (uiState.fallbackNotice != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFFFF3CD),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Fallback",
                                    tint = Color(0xFF856404),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = uiState.fallbackNotice ?: "",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF856404)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Topic & Source Chips Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DuoBlueLight
                        ) {
                            Text(
                                text = "⚛ ${currentQuestion.topic}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = DuoBlueDark,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }

                        if (currentQuestion.formulaHint != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFFFF9E6)
                            ) {
                                Text(
                                    text = "💡 ${currentQuestion.formulaHint}",
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 11.sp,
                                    color = Color(0xFF8A5B00),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Question Prompt Card
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = DuoWhite),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("question_card")
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "QUESTION ${uiState.currentQuestionIndex + 1}",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = DuoSubtext,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = currentQuestion.questionText,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = DuoDark,
                                lineHeight = 25.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 4 Multiple Choice Option Cards (A, B, C, D)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        currentQuestion.options.forEachIndexed { index, optionText ->
                            val letter = currentQuestion.getOptionLetter(index)
                            val isSelected = (uiState.selectedOptionIndex == index)

                            // Show correctness state once evaluated
                            val evalResult = uiState.evaluationResult
                            val correctness = if (evalResult != null) {
                                if (isSelected) evalResult.isCorrect else null
                            } else null

                            OptionCard(
                                letter = letter,
                                text = optionText,
                                isSelected = isSelected,
                                isCorrectEvaluation = correctness,
                                onClick = { viewModel.selectOption(index) }
                            )
                        }
                    }
                }

                // Bottom Action Bar or Evaluation Result Sheet
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                ) {
                    if (uiState.evaluationResult != null) {
                        EvaluationResultSheet(
                            result = uiState.evaluationResult!!,
                            onNextQuestion = { viewModel.nextQuestion() }
                        )
                    } else {
                        // Check Answer Button Surface
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(8.dp),
                            color = DuoWhite
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 14.dp)
                            ) {
                                if (uiState.isEvaluating) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(54.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(DuoBlueLight),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        CircularProgressIndicator(
                                            color = DuoBlue,
                                            strokeWidth = 3.dp,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = "Gemini AI Evaluating...",
                                            fontWeight = FontWeight.Bold,
                                            color = DuoBlueDark,
                                            fontSize = 15.sp
                                        )
                                    }
                                } else {
                                    val isSelected = (uiState.selectedOptionIndex != -1)
                                    DuoTactileButton(
                                        text = "CHECK ANSWER",
                                        enabled = isSelected,
                                        onClick = { viewModel.submitAnswer() },
                                        color = DuoGreen,
                                        shadowColor = DuoGreenDark,
                                        testTag = "check_answer_button"
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Dialogs
            if (uiState.showSettingsDialog) {
                ApiKeySettingsDialog(
                    key1 = uiState.key1,
                    key2 = uiState.key2,
                    key3 = uiState.key3,
                    onSaveKeys = { k1, k2, k3 -> viewModel.saveApiKeys(k1, k2, k3) },
                    onTestKey = { key -> viewModel.testApiKey(key) },
                    onDismiss = { viewModel.closeSettingsDialog() }
                )
            }

            if (uiState.showPdfDialog && uiState.loadedPdfName != null) {
                PdfUploadInfoDialog(
                    fileName = uiState.loadedPdfName ?: "Document.pdf",
                    pageCount = uiState.loadedPdfPageCount,
                    questionCount = uiState.loadedPdfQuestionCount,
                    previewBitmap = uiState.loadedPdfPreviewBitmap,
                    onSwitchToPdfQuestions = { viewModel.closePdfDialog() },
                    onResetToDefault = { viewModel.resetToDefaultQuestions() },
                    onPickNewPdf = {
                        pdfPickerLauncher.launch(arrayOf("application/pdf"))
                    },
                    onDismiss = { viewModel.closePdfDialog() }
                )
            }
        }
    }
}
