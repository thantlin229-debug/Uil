package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.decode.SvgDecoder
import coil.request.ImageRequest
import com.example.data.model.EvaluationResult
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

/**
 * Top bar with gamification stats (Streak, XP), PDF picker, and Gemini API keys settings.
 */
@Composable
fun DuoTopBar(
    totalXp: Int,
    streak: Int,
    activeSourceName: String,
    onOpenPdfPicker: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("duo_top_bar"),
        color = DuoWhite,
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App Branding & Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DuoGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = "MIIT Logo",
                        tint = DuoWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column {
                    Text(
                        text = "MIIT Mulingo",
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        color = DuoDark
                    )
                    Text(
                        text = activeSourceName.take(16) + if (activeSourceName.length > 16) "..." else "",
                        fontSize = 11.sp,
                        color = DuoSubtext,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Gamification & Action badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Streak Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFFFF3E0))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Streak",
                        tint = Color(0xFFFF9600),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "$streak",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFFD66900)
                    )
                }

                // XP Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(DuoGoldLight)
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "XP",
                        tint = DuoGoldDark,
                        modifier = Modifier.size(17.dp)
                    )
                    Text(
                        text = "$totalXp",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF9E6800)
                    )
                }

                // Document Picker Button
                IconButton(
                    onClick = onOpenPdfPicker,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DuoBlueLight)
                        .testTag("pdf_picker_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PictureAsPdf,
                        contentDescription = "Pick PDF",
                        tint = DuoBlueDark,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // API Key Settings Button
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFE8E8E8))
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Key,
                        contentDescription = "API Keys Settings",
                        tint = DuoDark,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

/**
 * Duolingo smooth animated progress bar.
 */
@Composable
fun DuoProgressBar(
    current: Int,
    total: Int,
    modifier: Modifier = Modifier
) {
    val progressFraction = if (total > 0) (current.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction,
        animationSpec = spring(stiffness = 200f),
        label = "progress_anim"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(16.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFE5E5E5))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(animatedProgress)
                .clip(RoundedCornerShape(8.dp))
                .background(DuoGreen)
        ) {
            // Shiny highlight bar on top of the progress
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .padding(horizontal = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0x66FFFFFF))
            )
        }
    }
}

/**
 * Duolingo 3D Tactile Button with press animation and bottom edge shadow.
 */
@Composable
fun DuoTactileButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    color: Color = DuoGreen,
    shadowColor: Color = DuoGreenDark,
    textColor: Color = DuoWhite,
    icon: @Composable (() -> Unit)? = null,
    testTag: String = "duo_tactile_button"
) {
    var isPressed by remember { mutableStateOf(false) }
    val offsetY by animateFloatAsState(
        targetValue = if (isPressed) 4f else 0f,
        label = "button_press_offset"
    )

    val actualColor = if (enabled) color else Color(0xFFD0D0D0)
    val actualShadow = if (enabled) shadowColor else Color(0xFFB5B5B5)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag(testTag)
            .pointerInput(enabled) {
                if (enabled) {
                    detectTapGestures(
                        onPress = {
                            isPressed = true
                            tryAwaitRelease()
                            isPressed = false
                            onClick()
                        }
                    )
                }
            }
    ) {
        // Bottom Shadow Layer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = 4.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(actualShadow)
        )
        // Top Surface Layer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(y = offsetY.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(actualColor),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) {
                    icon()
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = text,
                    fontWeight = FontWeight.Black,
                    fontSize = 17.sp,
                    color = textColor,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

/**
 * Multiple Choice Option Card (A, B, C, D) with Duolingo tactile feel.
 */
@Composable
fun OptionCard(
    letter: String,
    text: String,
    isSelected: Boolean,
    isCorrectEvaluation: Boolean? = null, // null = not evaluated, true = correct, false = wrong
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1f,
        label = "option_scale"
    )

    // Determine colors based on evaluation and selection state
    val (bgColor, borderColor, shadowColor, letterBgColor, letterTextColor) = when {
        isCorrectEvaluation == true -> {
            Tuple5(
                DuoGreenSoft,
                DuoGreen,
                DuoGreenDark,
                DuoGreen,
                DuoWhite
            )
        }
        isCorrectEvaluation == false && isSelected -> {
            Tuple5(
                DuoRedLight,
                DuoRed,
                DuoRedDark,
                DuoRed,
                DuoWhite
            )
        }
        isSelected -> {
            Tuple5(
                DuoBlueLight,
                DuoBlue,
                DuoBlueDark,
                DuoBlue,
                DuoWhite
            )
        }
        else -> {
            Tuple5(
                DuoWhite,
                DuoGrayBorder,
                Color(0xFFD6D6D6),
                Color(0xFFF0F0F0),
                DuoDark
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .scale(scale)
            .testTag("option_card_$letter")
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                        onClick()
                    }
                )
            }
    ) {
        // Bottom 3D shadow layer
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(y = 3.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(shadowColor)
        )

        // Main Card Surface
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(bgColor)
                .border(2.dp, borderColor, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Letter Badge (A, B, C, D)
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(letterBgColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = letter,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = letterTextColor
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Option text
            Text(
                text = text,
                fontSize = 16.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = DuoDark,
                modifier = Modifier.weight(1f)
            )

            // Evaluation icon indicator
            if (isCorrectEvaluation == true) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Correct",
                    tint = DuoGreenDark,
                    modifier = Modifier.size(24.dp)
                )
            } else if (isCorrectEvaluation == false && isSelected) {
                Icon(
                    imageVector = Icons.Default.Cancel,
                    contentDescription = "Incorrect",
                    tint = DuoRedDark,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

/**
 * Coil-powered raw SVG renderer for mascots (Star and Owl).
 */
@Composable
fun MascotSvgView(
    svgContent: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imageLoader = remember(context) {
        coil.ImageLoader.Builder(context)
            .components {
                add(SvgDecoder.Factory())
            }
            .build()
    }

    val byteArray = remember(svgContent) {
        svgContent.toByteArray(Charsets.UTF_8)
    }

    val request = remember(byteArray) {
        ImageRequest.Builder(context)
            .data(ByteBuffer.wrap(byteArray))
            .decoderFactory(SvgDecoder.Factory())
            .crossfade(true)
            .build()
    }

    AsyncImage(
        model = request,
        imageLoader = imageLoader,
        contentDescription = "Physics Mascot",
        modifier = modifier.testTag("mascot_svg_view")
    )
}

/**
 * Bottom Evaluation Sheet with mascot, Burmese physics concept, mental math trick, and Next button.
 */
@Composable
fun EvaluationResultSheet(
    result: EvaluationResult,
    onNextQuestion: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetBg = if (result.isCorrect) DuoGreenSoft else DuoRedLight
    val borderColor = if (result.isCorrect) DuoGreen else DuoRed
    val bannerTitle = if (result.isCorrect) "Fantastic! အဖြေမှန်ပါတယ်! 🎉" else "Good Effort! ပြန်လည်လေ့လာရအောင် 🦉"
    val bannerColor = if (result.isCorrect) DuoGreenDark else DuoRedDark

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .background(sheetBg)
            .border(2.dp, borderColor, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .testTag("evaluation_bottom_sheet"),
        color = sheetBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header: Mascot + Title + XP Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mascot SVG
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .padding(end = 12.dp)
                ) {
                    MascotSvgView(
                        svgContent = result.mascotSvg,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = bannerTitle,
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        color = bannerColor
                    )
                    Row(
                        modifier = Modifier.padding(top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DuoGold,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = "+${result.xpEarned} XP",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = Color(0xFF4A3B00),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = result.keyUsedInfo,
                            fontSize = 11.sp,
                            color = DuoSubtext,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Conversational Burmese Explanation Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DuoWhite),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Physics Concept",
                            tint = DuoBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Physics Concept (မြန်မာစကားပြေ)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DuoDark
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = result.explanationBurmese,
                        fontSize = 14.sp,
                        color = DuoDark,
                        lineHeight = 21.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Mental Math Shortcut Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9E6)),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Shortcut",
                            tint = Color(0xFFFF9600),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Mental Math Shortcut (လျင်မြန်စွာတွက်နည်း)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF8A5B00)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = result.mentalMathTip,
                        fontSize = 13.sp,
                        color = Color(0xFF4A3B00),
                        lineHeight = 19.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Big Tactile Next Button
            DuoTactileButton(
                text = "CONTINUE  ➔",
                onClick = onNextQuestion,
                color = if (result.isCorrect) DuoGreen else DuoBlue,
                shadowColor = if (result.isCorrect) DuoGreenDark else DuoBlueDark,
                testTag = "continue_button"
            )
        }
    }
}

/**
 * API Key Configuration Dialog (Up to 3 keys safely stored in EncryptedSharedPreferences).
 */
@Composable
fun ApiKeySettingsDialog(
    key1: String,
    key2: String,
    key3: String,
    onSaveKeys: (k1: String, k2: String, k3: String) -> Unit,
    onTestKey: suspend (key: String) -> Result<String>,
    onDismiss: () -> Unit
) {
    var k1State by remember { mutableStateOf(key1) }
    var k2State by remember { mutableStateOf(key2) }
    var k3State by remember { mutableStateOf(key3) }

    var testStatusMsg by remember { mutableStateOf<String?>(null) }
    var isTesting by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DuoWhite),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("api_key_settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DuoBlueLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = DuoBlueDark,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Gemini API Keys",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = DuoDark
                            )
                            Text(
                                text = "Multi-Key Auto Fallback (429)",
                                fontSize = 12.sp,
                                color = DuoSubtext
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = DuoSubtext)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Security notice banner
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFE8F5E9),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Encrypted",
                            tint = DuoGreenDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Stored securely in Android EncryptedSharedPreferences (AES-256)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = DuoGreenDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Key 1 Input (Primary)
                Text(
                    text = "Key 1 (Primary Key)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DuoDark
                )
                OutlinedTextField(
                    value = k1State,
                    onValueChange = { k1State = it },
                    placeholder = { Text("AIzaSy...") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 12.dp)
                        .testTag("key_1_input")
                )

                // Key 2 Input (Fallback)
                Text(
                    text = "Key 2 (Auto-Fallback if Key 1 hits 429)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DuoDark
                )
                OutlinedTextField(
                    value = k2State,
                    onValueChange = { k2State = it },
                    placeholder = { Text("AIzaSy... (Secondary)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 12.dp)
                        .testTag("key_2_input")
                )

                // Key 3 Input (Tertiary Fallback)
                Text(
                    text = "Key 3 (Tertiary Reserve)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DuoDark
                )
                OutlinedTextField(
                    value = k3State,
                    onValueChange = { k3State = it },
                    placeholder = { Text("AIzaSy... (Tertiary)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 16.dp)
                        .testTag("key_3_input")
                )

                // Test Status Message
                if (testStatusMsg != null) {
                    Text(
                        text = testStatusMsg ?: "",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (testStatusMsg!!.contains("Connected")) DuoGreenDark else DuoRedDark,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Test Button
                    OutlinedButton(
                        onClick = {
                            val activeKey = k1State.ifBlank { k2State.ifBlank { k3State } }
                            if (activeKey.isBlank()) {
                                testStatusMsg = "Please enter at least one key to test."
                                return@OutlinedButton
                            }
                            isTesting = true
                            testStatusMsg = "Testing key connectivity..."
                            coroutineScope.launch {
                                val res = onTestKey(activeKey)
                                isTesting = false
                                testStatusMsg = if (res.isSuccess) {
                                    "✓ ${res.getOrNull()}"
                                } else {
                                    "✗ ${res.exceptionOrNull()?.message ?: "Connection error"}"
                                }
                            }
                        },
                        enabled = !isTesting,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isTesting) "..." else "Test", fontWeight = FontWeight.Bold)
                    }

                    // Save Button
                    Button(
                        onClick = {
                            onSaveKeys(k1State, k2State, k3State)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DuoGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1.3f)
                    ) {
                        Text("Save Keys", fontWeight = FontWeight.Black, color = DuoWhite)
                    }
                }
            }
        }
    }
}

/**
 * PDF Document Sheet / Dialog showing extracted question details and options.
 */
@Composable
fun PdfUploadInfoDialog(
    fileName: String,
    pageCount: Int,
    questionCount: Int,
    previewBitmap: Bitmap?,
    onSwitchToPdfQuestions: () -> Unit,
    onResetToDefault: () -> Unit,
    onPickNewPdf: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DuoWhite),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("pdf_info_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Icon
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(DuoBlueLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = "PDF Icon",
                        tint = DuoBlueDark,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Physics PDF Document",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = DuoDark
                )

                Text(
                    text = fileName,
                    fontSize = 13.sp,
                    color = DuoSubtext,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // PDF Renderer Preview if available
                if (previewBitmap != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, DuoGrayBorder, RoundedCornerShape(12.dp))
                    ) {
                        Image(
                            bitmap = previewBitmap.asImageBitmap(),
                            contentDescription = "PDF Page 1 Preview",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Stats row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$pageCount", fontWeight = FontWeight.Black, fontSize = 20.sp, color = DuoBlueDark)
                        Text(text = "Pages", fontSize = 12.sp, color = DuoSubtext)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$questionCount", fontWeight = FontWeight.Black, fontSize = 20.sp, color = DuoGreenDark)
                        Text(text = "MCQ Questions", fontSize = 12.sp, color = DuoSubtext)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Load Questions Button
                DuoTactileButton(
                    text = "START THIS PDF DECK",
                    onClick = {
                        onSwitchToPdfQuestions()
                        onDismiss()
                    },
                    color = DuoGreen,
                    shadowColor = DuoGreenDark,
                    testTag = "start_pdf_deck_button"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Upload another PDF
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onPickNewPdf()
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pick Another PDF", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(6.dp))

                TextButton(
                    onClick = {
                        onResetToDefault()
                        onDismiss()
                    }
                ) {
                    Text("Reset to MIIT Standard Exam Deck", color = DuoSubtext, fontSize = 12.sp)
                }
            }
        }
    }
}

// Simple 5-tuple helper
data class Tuple5<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)
