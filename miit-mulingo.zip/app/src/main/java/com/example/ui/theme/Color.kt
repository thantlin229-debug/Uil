package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DuoGreen = Color(0xFF58CC02)
val DuoGreenDark = Color(0xFF46A302)
val DuoGreenLight = Color(0xFFD7FFB8)
val DuoGreenSoft = Color(0xFFE5F9D6)

val DuoBlue = Color(0xFF1CB0F6)
val DuoBlueDark = Color(0xFF1899D6)
val DuoBlueLight = Color(0xFFDDF4FF)

val DuoGold = Color(0xFFFFC800)
val DuoGoldDark = Color(0xFFE5A500)
val DuoGoldLight = Color(0xFFFFF5D6)

val DuoRed = Color(0xFFFF4B4B)
val DuoRedDark = Color(0xFFEA2B2B)
val DuoRedLight = Color(0xFFFFDFE0)

val DuoPurple = Color(0xFFCE82FF)
val DuoPurpleDark = Color(0xFFA55EEA)

val DuoDark = Color(0xFF3C3C3C)
val DuoSubtext = Color(0xFF777777)
val DuoGrayBorder = Color(0xFFE5E5E5)
val DuoGrayLight = Color(0xFFF7F7F7)
val DuoWhite = Color(0xFFFFFFFF)

