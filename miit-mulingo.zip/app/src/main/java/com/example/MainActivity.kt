package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.QuizScreen
import com.example.ui.theme.MIITMulingoTheme
import com.example.ui.viewmodel.QuizViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MIITMulingoTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          val quizViewModel: QuizViewModel = viewModel()
          QuizScreen(viewModel = quizViewModel)
        }
      }
    }
  }
}

