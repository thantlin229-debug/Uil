package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.SamplePhysicsQuestions
import com.example.data.security.SecurePreferences
import com.example.ui.mascots.MascotSvgs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("MIIT Mulingo", appName)
  }

  @Test
  fun `secure preferences stores and retrieves api keys`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = SecurePreferences(context)
    prefs.setApiKey(1, "test_key_1")
    prefs.setApiKey(2, "test_key_2")
    prefs.setApiKey(3, "test_key_3")

    assertEquals("test_key_1", prefs.getApiKey(1))
    assertEquals("test_key_2", prefs.getApiKey(2))
    assertEquals("test_key_3", prefs.getApiKey(3))
  }

  @Test
  fun `sample physics questions are valid`() {
    val questions = SamplePhysicsQuestions.defaultQuestions
    assertTrue("Questions list should not be empty", questions.isNotEmpty())
    for (q in questions) {
      assertEquals(4, q.options.size)
      assertTrue(q.correctIndex in 0..3)
    }
  }

  @Test
  fun `mascot svg sanitizer returns valid svg`() {
    val starSvg = MascotSvgs.sanitizeSvg(null, true)
    assertTrue(starSvg.contains("<svg") && starSvg.contains("</svg>"))

    val owlSvg = MascotSvgs.sanitizeSvg(null, false)
    assertTrue(owlSvg.contains("<svg") && owlSvg.contains("</svg>"))
  }
}

